Project Name: HTML Content Knowledge Check

Description: I made up a fictional book store and created a realistic Order Summary Page as if I had placed an order for this business.

HTML Concepts demonstrated
    - HTML5 Structure
    - Forms with multiple input types
    - Table with border
    - Navigation Bar with internal and external links
    - Adding images to a page
